"""Core module."""
from app.core.config import settings
